from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from ..api.auth import current_user
from ..database import get_db
from ..models.auth import User

router = APIRouter(prefix="/api/users", tags=["users"])


@router.get("")
async def list_users(_: User = Depends(current_user), db: AsyncSession = Depends(get_db)) -> list[dict[str, object]]:
    users = (await db.execute(select(User).order_by(User.username))).scalars()
    return [{"id": user.id, "username": user.username, "role": user.role} for user in users]
